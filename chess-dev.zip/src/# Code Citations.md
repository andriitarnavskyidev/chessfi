# Code Citations

## License: unknown
https://github.com/alexandre-jung/chess/blob/95ecc4adf62b1ba736d53262b66928db6aba1c4d/index.html

```
html lang="en">
```


## License: unknown
https://github.com/alexandre-jung/chess/blob/95ecc4adf62b1ba736d53262b66928db6aba1c4d/index.html

```
html lang="en">
  <head>
    <meta charset="UTF
```


## License: unknown
https://github.com/alexandre-jung/chess/blob/95ecc4adf62b1ba736d53262b66928db6aba1c4d/index.html

```
html lang="en">
  <head>
    <meta charset="UTF-8" />
    <link rel="icon"
```


## License: unknown
https://github.com/alexandre-jung/chess/blob/95ecc4adf62b1ba736d53262b66928db6aba1c4d/index.html

```
html lang="en">
  <head>
    <meta charset="UTF-8" />
    <link rel="icon" type="image/svg+xml" href="/chess
```


## License: unknown
https://github.com/alexandre-jung/chess/blob/95ecc4adf62b1ba736d53262b66928db6aba1c4d/index.html

```
html lang="en">
  <head>
    <meta charset="UTF-8" />
    <link rel="icon" type="image/svg+xml" href="/chess-icon.svg" />
    <meta
```


## License: unknown
https://github.com/alexandre-jung/chess/blob/95ecc4adf62b1ba736d53262b66928db6aba1c4d/index.html

```
html lang="en">
  <head>
    <meta charset="UTF-8" />
    <link rel="icon" type="image/svg+xml" href="/chess-icon.svg" />
    <meta name="viewport" content="width=
```


## License: unknown
https://github.com/alexandre-jung/chess/blob/95ecc4adf62b1ba736d53262b66928db6aba1c4d/index.html

```
html lang="en">
  <head>
    <meta charset="UTF-8" />
    <link rel="icon" type="image/svg+xml" href="/chess-icon.svg" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"
```


## License: unknown
https://github.com/matheus-vicente/codelandia-projetos/blob/8a87451f42626bff371c8907f4303b553f0ade0e/projeto-02/index.html

```
>
    <link
```


## License: unknown
https://github.com/davidgwong/davidgwong.github.io/blob/63aba9687fe4f22629ccc9ad41bd80c192e0fcc3/davidgwong.github.io/index.html

```
>
    <link href="https://fonts.googleapis.com/css2?
```


## License: unknown
https://github.com/matheus-vicente/codelandia-projetos/blob/8a87451f42626bff371c8907f4303b553f0ade0e/projeto-02/index.html

```
>
    <link href="https://fonts.googleapis.com/css2?
```


## License: unknown
https://github.com/davidgwong/davidgwong.github.io/blob/63aba9687fe4f22629ccc9ad41bd80c192e0fcc3/davidgwong.github.io/index.html

```
>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:w
```


## License: unknown
https://github.com/matheus-vicente/codelandia-projetos/blob/8a87451f42626bff371c8907f4303b553f0ade0e/projeto-02/index.html

```
>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:w
```


## License: unknown
https://github.com/davidgwong/davidgwong.github.io/blob/63aba9687fe4f22629ccc9ad41bd80c192e0fcc3/davidgwong.github.io/index.html

```
>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=
```


## License: unknown
https://github.com/yutao721/note/blob/f5ab8c9d34991ec274f7f652439afe5b2afb6147/docs/strong/134.react18.md

```
>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=
```


## License: unknown
https://github.com/matheus-vicente/codelandia-projetos/blob/8a87451f42626bff371c8907f4303b553f0ade0e/projeto-02/index.html

```
>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=
```


## License: unknown
https://github.com/davidgwong/davidgwong.github.io/blob/63aba9687fe4f22629ccc9ad41bd80c192e0fcc3/davidgwong.github.io/index.html

```
>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
  </head>
```


## License: unknown
https://github.com/yutao721/note/blob/f5ab8c9d34991ec274f7f652439afe5b2afb6147/docs/strong/134.react18.md

```
>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
  </head>
```


## License: unknown
https://github.com/matheus-vicente/codelandia-projetos/blob/8a87451f42626bff371c8907f4303b553f0ade0e/projeto-02/index.html

```
>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
  </head>
```


## License: unknown
https://github.com/davidgwong/davidgwong.github.io/blob/63aba9687fe4f22629ccc9ad41bd80c192e0fcc3/davidgwong.github.io/index.html

```
>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
  </head>
  <body>
    <div id="root">
```


## License: unknown
https://github.com/yutao721/note/blob/f5ab8c9d34991ec274f7f652439afe5b2afb6147/docs/strong/134.react18.md

```
>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
  </head>
  <body>
    <div id="root">
```


## License: unknown
https://github.com/matheus-vicente/codelandia-projetos/blob/8a87451f42626bff371c8907f4303b553f0ade0e/projeto-02/index.html

```
>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
  </head>
  <body>
    <div id="root">
```


## License: unknown
https://github.com/davidgwong/davidgwong.github.io/blob/63aba9687fe4f22629ccc9ad41bd80c192e0fcc3/davidgwong.github.io/index.html

```
>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/
```


## License: unknown
https://github.com/yutao721/note/blob/f5ab8c9d34991ec274f7f652439afe5b2afb6147/docs/strong/134.react18.md

```
>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/
```


## License: unknown
https://github.com/matheus-vicente/codelandia-projetos/blob/8a87451f42626bff371c8907f4303b553f0ade0e/projeto-02/index.html

```
>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/
```


## License: unknown
https://github.com/davidgwong/davidgwong.github.io/blob/63aba9687fe4f22629ccc9ad41bd80c192e0fcc3/davidgwong.github.io/index.html

```
>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
```


## License: unknown
https://github.com/yutao721/note/blob/f5ab8c9d34991ec274f7f652439afe5b2afb6147/docs/strong/134.react18.md

```
>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
```


## License: unknown
https://github.com/matheus-vicente/codelandia-projetos/blob/8a87451f42626bff371c8907f4303b553f0ade0e/projeto-02/index.html

```
>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
```


## License: unknown
https://github.com/davidgwong/davidgwong.github.io/blob/63aba9687fe4f22629ccc9ad41bd80c192e0fcc3/davidgwong.github.io/index.html

```
>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>
```

###
```


## License: unknown
https://github.com/yutao721/note/blob/f5ab8c9d34991ec274f7f652439afe5b2afb6147/docs/strong/134.react18.md

```
>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>
```

###
```


## License: unknown
https://github.com/matheus-vicente/codelandia-projetos/blob/8a87451f42626bff371c8907f4303b553f0ade0e/projeto-02/index.html

```
>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>
```

###
```


## License: unknown
https://github.com/Hades0050/example-orders/blob/0fa2f146dbc4973fec00dcfe5f02fcff71ed0fbd/dev-vue-example/src/app/styles/style.css

```
;
```


## License: unknown
https://github.com/Hades0050/example-orders/blob/0fa2f146dbc4973fec00dcfe5f02fcff71ed0fbd/dev-vue-example/src/app/styles/style.css

```
;
  line-height: 1.
```


## License: unknown
https://github.com/Hades0050/example-orders/blob/0fa2f146dbc4973fec00dcfe5f02fcff71ed0fbd/dev-vue-example/src/app/styles/style.css

```
;
  line-height: 1.5;
  font-weight:
```


## License: unknown
https://github.com/Hades0050/example-orders/blob/0fa2f146dbc4973fec00dcfe5f02fcff71ed0fbd/dev-vue-example/src/app/styles/style.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme
```


## License: unknown
https://github.com/bastien707/phoneStore/blob/05cf96254c62141995bdcf38d372bfab05586af4/frontend/src/index.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme
```


## License: unknown
https://github.com/Hades0050/example-orders/blob/0fa2f146dbc4973fec00dcfe5f02fcff71ed0fbd/dev-vue-example/src/app/styles/style.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color:
```


## License: unknown
https://github.com/pGarciaAndres/react-2023/blob/8fac84d088f7203aae3244d20adf8e4ef5990d89/projects/12-swr-route-news/src/App.scss

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color:
```


## License: unknown
https://github.com/bastien707/phoneStore/blob/05cf96254c62141995bdcf38d372bfab05586af4/frontend/src/index.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color:
```


## License: unknown
https://github.com/Hades0050/example-orders/blob/0fa2f146dbc4973fec00dcfe5f02fcff71ed0fbd/dev-vue-example/src/app/styles/style.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color
```


## License: unknown
https://github.com/pGarciaAndres/react-2023/blob/8fac84d088f7203aae3244d20adf8e4ef5990d89/projects/12-swr-route-news/src/App.scss

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color
```


## License: unknown
https://github.com/bastien707/phoneStore/blob/05cf96254c62141995bdcf38d372bfab05586af4/frontend/src/index.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color
```


## License: unknown
https://github.com/Hades0050/example-orders/blob/0fa2f146dbc4973fec00dcfe5f02fcff71ed0fbd/dev-vue-example/src/app/styles/style.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5
```


## License: unknown
https://github.com/pGarciaAndres/react-2023/blob/8fac84d088f7203aae3244d20adf8e4ef5990d89/projects/12-swr-route-news/src/App.scss

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5
```


## License: unknown
https://github.com/bastien707/phoneStore/blob/05cf96254c62141995bdcf38d372bfab05586af4/frontend/src/index.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5
```


## License: unknown
https://github.com/Hades0050/example-orders/blob/0fa2f146dbc4973fec00dcfe5f02fcff71ed0fbd/dev-vue-example/src/app/styles/style.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none
```


## License: unknown
https://github.com/pGarciaAndres/react-2023/blob/8fac84d088f7203aae3244d20adf8e4ef5990d89/projects/12-swr-route-news/src/App.scss

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none
```


## License: unknown
https://github.com/bastien707/phoneStore/blob/05cf96254c62141995bdcf38d372bfab05586af4/frontend/src/index.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none
```


## License: unknown
https://github.com/Hades0050/example-orders/blob/0fa2f146dbc4973fec00dcfe5f02fcff71ed0fbd/dev-vue-example/src/app/styles/style.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optim
```


## License: unknown
https://github.com/pGarciaAndres/react-2023/blob/8fac84d088f7203aae3244d20adf8e4ef5990d89/projects/12-swr-route-news/src/App.scss

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optim
```


## License: unknown
https://github.com/bastien707/phoneStore/blob/05cf96254c62141995bdcf38d372bfab05586af4/frontend/src/index.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optim
```


## License: unknown
https://github.com/Hades0050/example-orders/blob/0fa2f146dbc4973fec00dcfe5f02fcff71ed0fbd/dev-vue-example/src/app/styles/style.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-
```


## License: unknown
https://github.com/pGarciaAndres/react-2023/blob/8fac84d088f7203aae3244d20adf8e4ef5990d89/projects/12-swr-route-news/src/App.scss

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-
```


## License: unknown
https://github.com/bastien707/phoneStore/blob/05cf96254c62141995bdcf38d372bfab05586af4/frontend/src/index.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-
```


## License: unknown
https://github.com/Hades0050/example-orders/blob/0fa2f146dbc4973fec00dcfe5f02fcff71ed0fbd/dev-vue-example/src/app/styles/style.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
```


## License: unknown
https://github.com/pGarciaAndres/react-2023/blob/8fac84d088f7203aae3244d20adf8e4ef5990d89/projects/12-swr-route-news/src/App.scss

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
```


## License: unknown
https://github.com/bastien707/phoneStore/blob/05cf96254c62141995bdcf38d372bfab05586af4/frontend/src/index.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
```


## License: unknown
https://github.com/Hades0050/example-orders/blob/0fa2f146dbc4973fec00dcfe5f02fcff71ed0fbd/dev-vue-example/src/app/styles/style.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-
```


## License: unknown
https://github.com/pGarciaAndres/react-2023/blob/8fac84d088f7203aae3244d20adf8e4ef5990d89/projects/12-swr-route-news/src/App.scss

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-
```


## License: unknown
https://github.com/bastien707/phoneStore/blob/05cf96254c62141995bdcf38d372bfab05586af4/frontend/src/index.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-
```


## License: unknown
https://github.com/Hades0050/example-orders/blob/0fa2f146dbc4973fec00dcfe5f02fcff71ed0fbd/dev-vue-example/src/app/styles/style.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale
```


## License: unknown
https://github.com/pGarciaAndres/react-2023/blob/8fac84d088f7203aae3244d20adf8e4ef5990d89/projects/12-swr-route-news/src/App.scss

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale
```


## License: unknown
https://github.com/bastien707/phoneStore/blob/05cf96254c62141995bdcf38d372bfab05586af4/frontend/src/index.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale
```


## License: unknown
https://github.com/lawkunchi/one-pass-landing/blob/b14c58b1c322e610120e9d81fb0abb23ea2165de/src/index.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale
```


## License: unknown
https://github.com/Hades0050/example-orders/blob/0fa2f146dbc4973fec00dcfe5f02fcff71ed0fbd/dev-vue-example/src/app/styles/style.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 
```


## License: unknown
https://github.com/pGarciaAndres/react-2023/blob/8fac84d088f7203aae3244d20adf8e4ef5990d89/projects/12-swr-route-news/src/App.scss

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 
```


## License: unknown
https://github.com/bastien707/phoneStore/blob/05cf96254c62141995bdcf38d372bfab05586af4/frontend/src/index.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 
```


## License: unknown
https://github.com/lawkunchi/one-pass-landing/blob/b14c58b1c322e610120e9d81fb0abb23ea2165de/src/index.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 
```


## License: unknown
https://github.com/Hekidesk/BLE-react/blob/a83fb9cf9984bf5047be16d70f1b9bbcc6c696e3/src/index.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
```


## License: unknown
https://github.com/Hades0050/example-orders/blob/0fa2f146dbc4973fec00dcfe5f02fcff71ed0fbd/dev-vue-example/src/app/styles/style.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
```


## License: unknown
https://github.com/pGarciaAndres/react-2023/blob/8fac84d088f7203aae3244d20adf8e4ef5990d89/projects/12-swr-route-news/src/App.scss

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
```


## License: unknown
https://github.com/bastien707/phoneStore/blob/05cf96254c62141995bdcf38d372bfab05586af4/frontend/src/index.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
```


## License: unknown
https://github.com/lawkunchi/one-pass-landing/blob/b14c58b1c322e610120e9d81fb0abb23ea2165de/src/index.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
```


## License: unknown
https://github.com/Hekidesk/BLE-react/blob/a83fb9cf9984bf5047be16d70f1b9bbcc6c696e3/src/index.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px
```


## License: unknown
https://github.com/Hades0050/example-orders/blob/0fa2f146dbc4973fec00dcfe5f02fcff71ed0fbd/dev-vue-example/src/app/styles/style.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px
```


## License: unknown
https://github.com/pGarciaAndres/react-2023/blob/8fac84d088f7203aae3244d20adf8e4ef5990d89/projects/12-swr-route-news/src/App.scss

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px
```


## License: unknown
https://github.com/bastien707/phoneStore/blob/05cf96254c62141995bdcf38d372bfab05586af4/frontend/src/index.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px
```


## License: unknown
https://github.com/lawkunchi/one-pass-landing/blob/b14c58b1c322e610120e9d81fb0abb23ea2165de/src/index.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px
```


## License: unknown
https://github.com/Hekidesk/BLE-react/blob/a83fb9cf9984bf5047be16d70f1b9bbcc6c696e3/src/index.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 
```


## License: unknown
https://github.com/Hades0050/example-orders/blob/0fa2f146dbc4973fec00dcfe5f02fcff71ed0fbd/dev-vue-example/src/app/styles/style.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 
```


## License: unknown
https://github.com/pGarciaAndres/react-2023/blob/8fac84d088f7203aae3244d20adf8e4ef5990d89/projects/12-swr-route-news/src/App.scss

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 
```


## License: unknown
https://github.com/bastien707/phoneStore/blob/05cf96254c62141995bdcf38d372bfab05586af4/frontend/src/index.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 
```


## License: unknown
https://github.com/lawkunchi/one-pass-landing/blob/b14c58b1c322e610120e9d81fb0abb23ea2165de/src/index.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 
```


## License: unknown
https://github.com/Hekidesk/BLE-react/blob/a83fb9cf9984bf5047be16d70f1b9bbcc6c696e3/src/index.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#
```


## License: unknown
https://github.com/Hades0050/example-orders/blob/0fa2f146dbc4973fec00dcfe5f02fcff71ed0fbd/dev-vue-example/src/app/styles/style.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#
```


## License: unknown
https://github.com/pGarciaAndres/react-2023/blob/8fac84d088f7203aae3244d20adf8e4ef5990d89/projects/12-swr-route-news/src/App.scss

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#
```


## License: unknown
https://github.com/bastien707/phoneStore/blob/05cf96254c62141995bdcf38d372bfab05586af4/frontend/src/index.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#
```


## License: unknown
https://github.com/lawkunchi/one-pass-landing/blob/b14c58b1c322e610120e9d81fb0abb23ea2165de/src/index.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#
```


## License: unknown
https://github.com/Hekidesk/BLE-react/blob/a83fb9cf9984bf5047be16d70f1b9bbcc6c696e3/src/index.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#root {
  width: 100%;
```


## License: unknown
https://github.com/Hades0050/example-orders/blob/0fa2f146dbc4973fec00dcfe5f02fcff71ed0fbd/dev-vue-example/src/app/styles/style.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#root {
  width: 100%;
```


## License: unknown
https://github.com/pGarciaAndres/react-2023/blob/8fac84d088f7203aae3244d20adf8e4ef5990d89/projects/12-swr-route-news/src/App.scss

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#root {
  width: 100%;
```


## License: unknown
https://github.com/bastien707/phoneStore/blob/05cf96254c62141995bdcf38d372bfab05586af4/frontend/src/index.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#root {
  width: 100%;
```


## License: unknown
https://github.com/lawkunchi/one-pass-landing/blob/b14c58b1c322e610120e9d81fb0abb23ea2165de/src/index.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#root {
  width: 100%;
```


## License: unknown
https://github.com/Hekidesk/BLE-react/blob/a83fb9cf9984bf5047be16d70f1b9bbcc6c696e3/src/index.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#root {
  width: 100%;
}

button {
  border
```


## License: unknown
https://github.com/Hades0050/example-orders/blob/0fa2f146dbc4973fec00dcfe5f02fcff71ed0fbd/dev-vue-example/src/app/styles/style.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#root {
  width: 100%;
}

button {
  border
```


## License: unknown
https://github.com/pGarciaAndres/react-2023/blob/8fac84d088f7203aae3244d20adf8e4ef5990d89/projects/12-swr-route-news/src/App.scss

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#root {
  width: 100%;
}

button {
  border
```


## License: unknown
https://github.com/bastien707/phoneStore/blob/05cf96254c62141995bdcf38d372bfab05586af4/frontend/src/index.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#root {
  width: 100%;
}

button {
  border
```


## License: unknown
https://github.com/lawkunchi/one-pass-landing/blob/b14c58b1c322e610120e9d81fb0abb23ea2165de/src/index.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#root {
  width: 100%;
}

button {
  border
```


## License: unknown
https://github.com/Hekidesk/BLE-react/blob/a83fb9cf9984bf5047be16d70f1b9bbcc6c696e3/src/index.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#root {
  width: 100%;
}

button {
  border-radius: 8px;
  
```


## License: unknown
https://github.com/Hades0050/example-orders/blob/0fa2f146dbc4973fec00dcfe5f02fcff71ed0fbd/dev-vue-example/src/app/styles/style.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#root {
  width: 100%;
}

button {
  border-radius: 8px;
  
```


## License: unknown
https://github.com/pGarciaAndres/react-2023/blob/8fac84d088f7203aae3244d20adf8e4ef5990d89/projects/12-swr-route-news/src/App.scss

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#root {
  width: 100%;
}

button {
  border-radius: 8px;
  
```


## License: unknown
https://github.com/bastien707/phoneStore/blob/05cf96254c62141995bdcf38d372bfab05586af4/frontend/src/index.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#root {
  width: 100%;
}

button {
  border-radius: 8px;
  
```


## License: unknown
https://github.com/lawkunchi/one-pass-landing/blob/b14c58b1c322e610120e9d81fb0abb23ea2165de/src/index.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#root {
  width: 100%;
}

button {
  border-radius: 8px;
  
```


## License: unknown
https://github.com/Hekidesk/BLE-react/blob/a83fb9cf9984bf5047be16d70f1b9bbcc6c696e3/src/index.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#root {
  width: 100%;
}

button {
  border-radius: 8px;
  border: 1px
```


## License: unknown
https://github.com/Hades0050/example-orders/blob/0fa2f146dbc4973fec00dcfe5f02fcff71ed0fbd/dev-vue-example/src/app/styles/style.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#root {
  width: 100%;
}

button {
  border-radius: 8px;
  border: 1px
```


## License: unknown
https://github.com/pGarciaAndres/react-2023/blob/8fac84d088f7203aae3244d20adf8e4ef5990d89/projects/12-swr-route-news/src/App.scss

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#root {
  width: 100%;
}

button {
  border-radius: 8px;
  border: 1px
```


## License: unknown
https://github.com/bastien707/phoneStore/blob/05cf96254c62141995bdcf38d372bfab05586af4/frontend/src/index.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#root {
  width: 100%;
}

button {
  border-radius: 8px;
  border: 1px
```


## License: unknown
https://github.com/lawkunchi/one-pass-landing/blob/b14c58b1c322e610120e9d81fb0abb23ea2165de/src/index.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#root {
  width: 100%;
}

button {
  border-radius: 8px;
  border: 1px
```


## License: unknown
https://github.com/Hekidesk/BLE-react/blob/a83fb9cf9984bf5047be16d70f1b9bbcc6c696e3/src/index.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#root {
  width: 100%;
}

button {
  border-radius: 8px;
  border: 1px solid transparent;
  padding: 
```


## License: unknown
https://github.com/Hades0050/example-orders/blob/0fa2f146dbc4973fec00dcfe5f02fcff71ed0fbd/dev-vue-example/src/app/styles/style.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#root {
  width: 100%;
}

button {
  border-radius: 8px;
  border: 1px solid transparent;
  padding: 
```


## License: unknown
https://github.com/pGarciaAndres/react-2023/blob/8fac84d088f7203aae3244d20adf8e4ef5990d89/projects/12-swr-route-news/src/App.scss

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#root {
  width: 100%;
}

button {
  border-radius: 8px;
  border: 1px solid transparent;
  padding: 
```


## License: unknown
https://github.com/bastien707/phoneStore/blob/05cf96254c62141995bdcf38d372bfab05586af4/frontend/src/index.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#root {
  width: 100%;
}

button {
  border-radius: 8px;
  border: 1px solid transparent;
  padding: 
```


## License: unknown
https://github.com/lawkunchi/one-pass-landing/blob/b14c58b1c322e610120e9d81fb0abb23ea2165de/src/index.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#root {
  width: 100%;
}

button {
  border-radius: 8px;
  border: 1px solid transparent;
  padding: 
```


## License: unknown
https://github.com/Hekidesk/BLE-react/blob/a83fb9cf9984bf5047be16d70f1b9bbcc6c696e3/src/index.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#root {
  width: 100%;
}

button {
  border-radius: 8px;
  border: 1px solid transparent;
  padding: 0.6em 1.2
```


## License: unknown
https://github.com/Hades0050/example-orders/blob/0fa2f146dbc4973fec00dcfe5f02fcff71ed0fbd/dev-vue-example/src/app/styles/style.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#root {
  width: 100%;
}

button {
  border-radius: 8px;
  border: 1px solid transparent;
  padding: 0.6em 1.2
```


## License: unknown
https://github.com/pGarciaAndres/react-2023/blob/8fac84d088f7203aae3244d20adf8e4ef5990d89/projects/12-swr-route-news/src/App.scss

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#root {
  width: 100%;
}

button {
  border-radius: 8px;
  border: 1px solid transparent;
  padding: 0.6em 1.2
```


## License: unknown
https://github.com/bastien707/phoneStore/blob/05cf96254c62141995bdcf38d372bfab05586af4/frontend/src/index.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#root {
  width: 100%;
}

button {
  border-radius: 8px;
  border: 1px solid transparent;
  padding: 0.6em 1.2
```


## License: unknown
https://github.com/lawkunchi/one-pass-landing/blob/b14c58b1c322e610120e9d81fb0abb23ea2165de/src/index.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#root {
  width: 100%;
}

button {
  border-radius: 8px;
  border: 1px solid transparent;
  padding: 0.6em 1.2
```


## License: unknown
https://github.com/Hekidesk/BLE-react/blob/a83fb9cf9984bf5047be16d70f1b9bbcc6c696e3/src/index.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#root {
  width: 100%;
}

button {
  border-radius: 8px;
  border: 1px solid transparent;
  padding: 0.6em 1.2em;
  font-size:
```


## License: unknown
https://github.com/Hades0050/example-orders/blob/0fa2f146dbc4973fec00dcfe5f02fcff71ed0fbd/dev-vue-example/src/app/styles/style.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#root {
  width: 100%;
}

button {
  border-radius: 8px;
  border: 1px solid transparent;
  padding: 0.6em 1.2em;
  font-size:
```


## License: unknown
https://github.com/pGarciaAndres/react-2023/blob/8fac84d088f7203aae3244d20adf8e4ef5990d89/projects/12-swr-route-news/src/App.scss

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#root {
  width: 100%;
}

button {
  border-radius: 8px;
  border: 1px solid transparent;
  padding: 0.6em 1.2em;
  font-size:
```


## License: unknown
https://github.com/bastien707/phoneStore/blob/05cf96254c62141995bdcf38d372bfab05586af4/frontend/src/index.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#root {
  width: 100%;
}

button {
  border-radius: 8px;
  border: 1px solid transparent;
  padding: 0.6em 1.2em;
  font-size:
```


## License: unknown
https://github.com/lawkunchi/one-pass-landing/blob/b14c58b1c322e610120e9d81fb0abb23ea2165de/src/index.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#root {
  width: 100%;
}

button {
  border-radius: 8px;
  border: 1px solid transparent;
  padding: 0.6em 1.2em;
  font-size:
```


## License: unknown
https://github.com/Hekidesk/BLE-react/blob/a83fb9cf9984bf5047be16d70f1b9bbcc6c696e3/src/index.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#root {
  width: 100%;
}

button {
  border-radius: 8px;
  border: 1px solid transparent;
  padding: 0.6em 1.2em;
  font-size: 1em;
  font-
```


## License: unknown
https://github.com/Hades0050/example-orders/blob/0fa2f146dbc4973fec00dcfe5f02fcff71ed0fbd/dev-vue-example/src/app/styles/style.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#root {
  width: 100%;
}

button {
  border-radius: 8px;
  border: 1px solid transparent;
  padding: 0.6em 1.2em;
  font-size: 1em;
  font-
```


## License: unknown
https://github.com/pGarciaAndres/react-2023/blob/8fac84d088f7203aae3244d20adf8e4ef5990d89/projects/12-swr-route-news/src/App.scss

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#root {
  width: 100%;
}

button {
  border-radius: 8px;
  border: 1px solid transparent;
  padding: 0.6em 1.2em;
  font-size: 1em;
  font-
```


## License: unknown
https://github.com/bastien707/phoneStore/blob/05cf96254c62141995bdcf38d372bfab05586af4/frontend/src/index.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#root {
  width: 100%;
}

button {
  border-radius: 8px;
  border: 1px solid transparent;
  padding: 0.6em 1.2em;
  font-size: 1em;
  font-
```


## License: unknown
https://github.com/lawkunchi/one-pass-landing/blob/b14c58b1c322e610120e9d81fb0abb23ea2165de/src/index.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#root {
  width: 100%;
}

button {
  border-radius: 8px;
  border: 1px solid transparent;
  padding: 0.6em 1.2em;
  font-size: 1em;
  font-
```


## License: unknown
https://github.com/Hekidesk/BLE-react/blob/a83fb9cf9984bf5047be16d70f1b9bbcc6c696e3/src/index.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#root {
  width: 100%;
}

button {
  border-radius: 8px;
  border: 1px solid transparent;
  padding: 0.6em 1.2em;
  font-size: 1em;
  font-weight: 500;
  font
```


## License: unknown
https://github.com/Hades0050/example-orders/blob/0fa2f146dbc4973fec00dcfe5f02fcff71ed0fbd/dev-vue-example/src/app/styles/style.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#root {
  width: 100%;
}

button {
  border-radius: 8px;
  border: 1px solid transparent;
  padding: 0.6em 1.2em;
  font-size: 1em;
  font-weight: 500;
  font
```


## License: unknown
https://github.com/pGarciaAndres/react-2023/blob/8fac84d088f7203aae3244d20adf8e4ef5990d89/projects/12-swr-route-news/src/App.scss

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#root {
  width: 100%;
}

button {
  border-radius: 8px;
  border: 1px solid transparent;
  padding: 0.6em 1.2em;
  font-size: 1em;
  font-weight: 500;
  font
```


## License: unknown
https://github.com/bastien707/phoneStore/blob/05cf96254c62141995bdcf38d372bfab05586af4/frontend/src/index.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#root {
  width: 100%;
}

button {
  border-radius: 8px;
  border: 1px solid transparent;
  padding: 0.6em 1.2em;
  font-size: 1em;
  font-weight: 500;
  font
```


## License: unknown
https://github.com/lawkunchi/one-pass-landing/blob/b14c58b1c322e610120e9d81fb0abb23ea2165de/src/index.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#root {
  width: 100%;
}

button {
  border-radius: 8px;
  border: 1px solid transparent;
  padding: 0.6em 1.2em;
  font-size: 1em;
  font-weight: 500;
  font
```


## License: unknown
https://github.com/Hekidesk/BLE-react/blob/a83fb9cf9984bf5047be16d70f1b9bbcc6c696e3/src/index.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#root {
  width: 100%;
}

button {
  border-radius: 8px;
  border: 1px solid transparent;
  padding: 0.6em 1.2em;
  font-size: 1em;
  font-weight: 500;
  font-family: inherit;
  backgroun
```


## License: unknown
https://github.com/Hades0050/example-orders/blob/0fa2f146dbc4973fec00dcfe5f02fcff71ed0fbd/dev-vue-example/src/app/styles/style.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#root {
  width: 100%;
}

button {
  border-radius: 8px;
  border: 1px solid transparent;
  padding: 0.6em 1.2em;
  font-size: 1em;
  font-weight: 500;
  font-family: inherit;
  backgroun
```


## License: unknown
https://github.com/pGarciaAndres/react-2023/blob/8fac84d088f7203aae3244d20adf8e4ef5990d89/projects/12-swr-route-news/src/App.scss

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#root {
  width: 100%;
}

button {
  border-radius: 8px;
  border: 1px solid transparent;
  padding: 0.6em 1.2em;
  font-size: 1em;
  font-weight: 500;
  font-family: inherit;
  backgroun
```


## License: unknown
https://github.com/bastien707/phoneStore/blob/05cf96254c62141995bdcf38d372bfab05586af4/frontend/src/index.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#root {
  width: 100%;
}

button {
  border-radius: 8px;
  border: 1px solid transparent;
  padding: 0.6em 1.2em;
  font-size: 1em;
  font-weight: 500;
  font-family: inherit;
  backgroun
```


## License: unknown
https://github.com/lawkunchi/one-pass-landing/blob/b14c58b1c322e610120e9d81fb0abb23ea2165de/src/index.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#root {
  width: 100%;
}

button {
  border-radius: 8px;
  border: 1px solid transparent;
  padding: 0.6em 1.2em;
  font-size: 1em;
  font-weight: 500;
  font-family: inherit;
  backgroun
```


## License: unknown
https://github.com/Hekidesk/BLE-react/blob/a83fb9cf9984bf5047be16d70f1b9bbcc6c696e3/src/index.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#root {
  width: 100%;
}

button {
  border-radius: 8px;
  border: 1px solid transparent;
  padding: 0.6em 1.2em;
  font-size: 1em;
  font-weight: 500;
  font-family: inherit;
  background-color:
```


## License: unknown
https://github.com/Hades0050/example-orders/blob/0fa2f146dbc4973fec00dcfe5f02fcff71ed0fbd/dev-vue-example/src/app/styles/style.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#root {
  width: 100%;
}

button {
  border-radius: 8px;
  border: 1px solid transparent;
  padding: 0.6em 1.2em;
  font-size: 1em;
  font-weight: 500;
  font-family: inherit;
  background-color:
```


## License: unknown
https://github.com/pGarciaAndres/react-2023/blob/8fac84d088f7203aae3244d20adf8e4ef5990d89/projects/12-swr-route-news/src/App.scss

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#root {
  width: 100%;
}

button {
  border-radius: 8px;
  border: 1px solid transparent;
  padding: 0.6em 1.2em;
  font-size: 1em;
  font-weight: 500;
  font-family: inherit;
  background-color:
```


## License: unknown
https://github.com/bastien707/phoneStore/blob/05cf96254c62141995bdcf38d372bfab05586af4/frontend/src/index.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#root {
  width: 100%;
}

button {
  border-radius: 8px;
  border: 1px solid transparent;
  padding: 0.6em 1.2em;
  font-size: 1em;
  font-weight: 500;
  font-family: inherit;
  background-color:
```


## License: unknown
https://github.com/lawkunchi/one-pass-landing/blob/b14c58b1c322e610120e9d81fb0abb23ea2165de/src/index.css

```
;
  line-height: 1.5;
  font-weight: 400;

  color-scheme: light dark;
  color: #242424;
  background-color: #f5f5f5;

  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

#root {
  width: 100%;
}

button {
  border-radius: 8px;
  border: 1px solid transparent;
  padding: 0.6em 1.2em;
  font-size: 1em;
  font-weight: 500;
  font-family: inherit;
  background-color:
```


## License: unknown
https://github.com/jsonpickle/jsonpickle.github.io/blob/faaad8df8c06792e26912939e442f52250f345bb/index.html

```
.svg -->

```


## License: unknown
https://github.com/Suandika12/PA2-Kel13/blob/ca563ee96ef81c5db3d0b5c8b92bb69bf9f870cc/api_numero_sada/resources/views/layouts/aside.blade.php

```
.svg -->

```


## License: unknown
https://github.com/jsonpickle/jsonpickle.github.io/blob/faaad8df8c06792e26912939e442f52250f345bb/index.html

```
.svg -->
<svg xmlns="http://www.w3.org/
```


## License: unknown
https://github.com/zqureshi/zqureshi.github.com/blob/054e91a9490d9e228a6d1af88a6bec58b97baee4/themes/papermod/layouts/partials/svg.html

```
.svg -->
<svg xmlns="http://www.w3.org/
```


## License: unknown
https://github.com/Suandika12/PA2-Kel13/blob/ca563ee96ef81c5db3d0b5c8b92bb69bf9f870cc/api_numero_sada/resources/views/layouts/aside.blade.php

```
.svg -->
<svg xmlns="http://www.w3.org/
```


## License: unknown
https://github.com/jsonpickle/jsonpickle.github.io/blob/faaad8df8c06792e26912939e442f52250f345bb/index.html

```
.svg -->
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 
```


## License: unknown
https://github.com/zqureshi/zqureshi.github.com/blob/054e91a9490d9e228a6d1af88a6bec58b97baee4/themes/papermod/layouts/partials/svg.html

```
.svg -->
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 
```


## License: unknown
https://github.com/Suandika12/PA2-Kel13/blob/ca563ee96ef81c5db3d0b5c8b92bb69bf9f870cc/api_numero_sada/resources/views/layouts/aside.blade.php

```
.svg -->
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 
```


## License: unknown
https://github.com/jsonpickle/jsonpickle.github.io/blob/faaad8df8c06792e26912939e442f52250f345bb/index.html

```
.svg -->
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none
```


## License: unknown
https://github.com/zqureshi/zqureshi.github.com/blob/054e91a9490d9e228a6d1af88a6bec58b97baee4/themes/papermod/layouts/partials/svg.html

```
.svg -->
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none
```


## License: unknown
https://github.com/Suandika12/PA2-Kel13/blob/ca563ee96ef81c5db3d0b5c8b92bb69bf9f870cc/api_numero_sada/resources/views/layouts/aside.blade.php

```
.svg -->
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none
```


## License: unknown
https://github.com/jsonpickle/jsonpickle.github.io/blob/faaad8df8c06792e26912939e442f52250f345bb/index.html

```
.svg -->
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-
```


## License: unknown
https://github.com/zqureshi/zqureshi.github.com/blob/054e91a9490d9e228a6d1af88a6bec58b97baee4/themes/papermod/layouts/partials/svg.html

```
.svg -->
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-
```


## License: unknown
https://github.com/Suandika12/PA2-Kel13/blob/ca563ee96ef81c5db3d0b5c8b92bb69bf9f870cc/api_numero_sada/resources/views/layouts/aside.blade.php

```
.svg -->
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-
```


## License: unknown
https://github.com/jsonpickle/jsonpickle.github.io/blob/faaad8df8c06792e26912939e442f52250f345bb/index.html

```
.svg -->
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linec
```


## License: unknown
https://github.com/zqureshi/zqureshi.github.com/blob/054e91a9490d9e228a6d1af88a6bec58b97baee4/themes/papermod/layouts/partials/svg.html

```
.svg -->
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linec
```


## License: unknown
https://github.com/Suandika12/PA2-Kel13/blob/ca563ee96ef81c5db3d0b5c8b92bb69bf9f870cc/api_numero_sada/resources/views/layouts/aside.blade.php

```
.svg -->
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linec
```


## License: unknown
https://github.com/jsonpickle/jsonpickle.github.io/blob/faaad8df8c06792e26912939e442f52250f345bb/index.html

```
.svg -->
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linej
```


## License: unknown
https://github.com/zqureshi/zqureshi.github.com/blob/054e91a9490d9e228a6d1af88a6bec58b97baee4/themes/papermod/layouts/partials/svg.html

```
.svg -->
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linej
```


## License: unknown
https://github.com/Suandika12/PA2-Kel13/blob/ca563ee96ef81c5db3d0b5c8b92bb69bf9f870cc/api_numero_sada/resources/views/layouts/aside.blade.php

```
.svg -->
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linej
```


## License: unknown
https://github.com/jsonpickle/jsonpickle.github.io/blob/faaad8df8c06792e26912939e442f52250f345bb/index.html

```
.svg -->
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
  <path d=
```


## License: unknown
https://github.com/zqureshi/zqureshi.github.com/blob/054e91a9490d9e228a6d1af88a6bec58b97baee4/themes/papermod/layouts/partials/svg.html

```
.svg -->
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
  <path d=
```


## License: unknown
https://github.com/Suandika12/PA2-Kel13/blob/ca563ee96ef81c5db3d0b5c8b92bb69bf9f870cc/api_numero_sada/resources/views/layouts/aside.blade.php

```
.svg -->
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
  <path d=
```

